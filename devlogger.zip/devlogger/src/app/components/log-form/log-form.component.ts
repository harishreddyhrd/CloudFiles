import { Component, OnInit } from '@angular/core';
import { Log } from 'src/app/models/Log';
import { LogService } from 'src/app/services/log.service';

@Component({
  selector: 'app-log-form',
  templateUrl: './log-form.component.html',
  styleUrls: ['./log-form.component.scss'],
})
export class LogFormComponent implements OnInit {
  id: string = '';
  description: string = '';
  date: any;

  isNewLog: boolean = true;

  constructor(private _logService: LogService) {}

  ngOnInit(): void {
    this._logService.theSelectedLog.subscribe((selected_log: Log) => {
      console.log('Pull Selected Log into - LogFormComponent', selected_log);
      if (selected_log.id) {
        this.isNewLog = false;
        this.id = selected_log.id;
        this.description = selected_log.description;
        this.date = selected_log.date;
      }
    });
  }

  onSubmit() {
    //Check if adding new log or updating existing log
    if (this.isNewLog) {
      //if adding new log then create a new log with 
      const theNewLog = {
        //new UUID
        id: this.generateUUID(),
        //new Description
        description: this.description,
        //new Date
        date: new Date(),
      };
      //and add that to logs list
      this._logService.addLog(theNewLog);
    } else {
      //if updating the existing log then edit the log with
      const theEditedLog = {
        //selected log id
        id: this.id,
        description: this.description,
        date: new Date(),
      };
      //and update that in logs list
      this._logService.updateLog(theEditedLog);
    }

    //ClearState
    this.clearLogForm();
  }

  clearLogForm() {
    this.isNewLog = true;
    this.id = '';
    this.description = '';
    this.date = null;
    this._logService.resetForm();
  }


  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(
      /[xy]/g,
      function (c) {
        var r = (Math.random() * 16) | 0,
          v = c == 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }
    );
  }
}
