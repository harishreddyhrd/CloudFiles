import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Log } from '../../models/Log';
import { LogService } from '../../services/log.service';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss'],
})
export class LogsComponent implements OnInit {
  logs!: Log[];
  theClickedLog!: Log;
  areLogsLoaded: boolean = false;
  constructor(private _logService: LogService) {}

  ngOnInit(): void {
    this._logService.getLogs().subscribe((logData: Log[]) => {
      console.log('List of Logs: ', logData);
      this.logs = logData;
      this.areLogsLoaded = true;
    });

    // //Method1: Grab the logs released by the _logService as an array
    // this.logs = this._logService.getLogs();
    // console.log(this.logs);
  }

  onLogSelection(selected_log: Log) {
    console.log('LogsComponent - Selected LOG: ', selected_log);
    this._logService.setFormWith(selected_log);
    this.theClickedLog = selected_log;
  }

  onDeletion(selected_log: Log) {
    if (confirm('Are you sure wanna delete this log?')) {
      this._logService.deleteLog(selected_log);
    }
  }
}
