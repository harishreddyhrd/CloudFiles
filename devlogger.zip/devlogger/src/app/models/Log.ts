export interface Log {
  id: string;
  description: string;
  date: any;
}