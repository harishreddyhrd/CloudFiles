import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Log } from '../models/Log';

@Injectable({
  providedIn: 'root',
})
export class LogService {
  logs: Log[];

  constructor() {
    // this.logs = [
    //   {
    //     id: '1',
    //     description: 'Generated Components',
    //     date: new Date('20 April 2021 09:16:58'),
    //   },
    //   {
    //     id: '2',
    //     description: 'Added Bootstrap & UI',
    //     date: new Date('20 April 2021 09:34:18'),
    //   },
    //   {
    //     id: '3',
    //     description: 'Added Logs Component',
    //     date: new Date('21 April 2021 10:16:58'),
    //   },
    // ];

    this.logs = [];
  }

  getLogs(): Observable<Log[]> {
    //Get Logs from Local storage
    if (localStorage.getItem('Logs') === null) {
      this.logs = [];
    } else {
      this.logs = JSON.parse(localStorage.getItem('Logs')!);
    }
    //return them in the ascending order of date created;
    return of(
      this.logs.sort((a, b) => {
        return b.date - a.date;
      })
    );
  }

  // //Method1: Returning logData as an array
  // getLogs(): Log[] {
  //   return this.logs;
  // }

  //{
  private _logSelection = new BehaviorSubject<Log>({
    id: '',
    description: '',
    date: null,
  });
  theSelectedLog = this._logSelection.asObservable();
  setFormWith(selected_log: Log) {
    this._logSelection.next(selected_log);
  }
  //}

  addLog(new_log: Log) {
    console.log('Adding Log: ', new_log);
    this.logs.unshift(new_log);

    //Add Log to LocalStorage
    localStorage.setItem('Logs', JSON.stringify(this.logs));
  }

  updateLog(edited_log: Log) {
    console.log('Edited Log: ', edited_log);

    this.deleteLog(edited_log);
    this.logs.unshift(edited_log);
    //Update Logs in Local storage
    localStorage.setItem('Logs', JSON.stringify(this.logs));
  }

  deleteLog(selected_log: Log) {
    this.logs.forEach((current_log, index) => {
      if (selected_log.id === current_log.id) {
        this.logs.splice(index, 1);
      }
    });

    //Delete Log from Local storage
    localStorage.setItem('Logs', JSON.stringify(this.logs));
  }

  // {
  private _clearSelection = new BehaviorSubject<boolean>(true);
  stateClear = this._clearSelection.asObservable();
  resetForm() {
    this._clearSelection.next(true);
  }
  // }
}
